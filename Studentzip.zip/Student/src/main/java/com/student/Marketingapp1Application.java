package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Marketingapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Marketingapp1Application.class, args);
	}

}
