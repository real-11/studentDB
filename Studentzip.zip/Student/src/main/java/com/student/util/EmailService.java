package com.student.util;

public interface EmailService {

	public void sendEmail(String to,String sub, String msg);
		
	
}
